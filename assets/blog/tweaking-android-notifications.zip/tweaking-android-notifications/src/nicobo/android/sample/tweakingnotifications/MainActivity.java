package nicobo.android.sample.tweakingnotifications;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

/**
 * The main page of the application shows its preferences, since there is no GUI
 * except the notification item.
 */
public class MainActivity extends Activity {

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);

		setContentView(R.layout.main);

		Button btNotif1 = (Button) findViewById(R.id.bt_notiffull);
		btNotif1.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				startService(new Intent(NotifyService.ACTION_FULL, null, v
						.getContext(), NotifyService.class));
			}
		});

		Button btNotif2 = (Button) findViewById(R.id.bt_notiflongdate);
		btNotif2.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				startService(new Intent(NotifyService.ACTION_LONGDATE, null, v
						.getContext(), NotifyService.class));
			}
		});

		Button btNotif3 = (Button) findViewById(R.id.bt_notifvisibleicon);
		btNotif3.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				startService(new Intent(NotifyService.ACTION_VISIBLEICON, null,
						v.getContext(), NotifyService.class));
			}
		});

		Button btKillNotif = (Button) findViewById(R.id.bt_killnotif);
		btKillNotif.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				NotifyService.stop(v.getContext());
			}
		});
	}

	@Override
	protected void onDestroy() {
		NotifyService.stop(this);
		super.onDestroy();
	}
}