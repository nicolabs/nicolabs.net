package nicobo.android.sample.tweakingnotifications;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

/** This service creates the notification item and exits */
public class NotifyService extends Service {

	public static final String ACTION_FULL = "full";
	public static final String ACTION_LONGDATE = "longDate";
	public static final String ACTION_VISIBLEICON = "visibleIcon";

	private static final String TAG = NotifyService.class.getName();

	private static final int SDK_VERSION = Integer.parseInt(Build.VERSION.SDK);

	/**
	 * The time of the notification rules if it is aligned to the right or left
	 * of the notification bar, and therefore we use it to place the empty icon
	 * where it will not be noticed by the user.
	 */
	private static final long TIME_HIDDEN = SDK_VERSION >= 9 ? -Long.MAX_VALUE
			: Long.MAX_VALUE;

	/** Displayed when the service is started */
	private static final int NOTIF_START = 1;

	/**
	 * Stops this service.
	 * 
	 * <p>
	 * <i>Helper method.</i>
	 * </p>
	 */
	public static void stop(Context context) {
		NotificationManager nm = (NotificationManager) context
				.getSystemService(Context.NOTIFICATION_SERVICE);
		nm.cancelAll();
	}

	/** Creates a notification and hides its icon in the notification bar */
	// from http://developer.android.com/guide/topics/ui/notifiers/notifications.html
	// and http://stackoverflow.com/questions/2855110/android-no-icon-for-notification
	private Notification buildNotificationFull() {

		Resources resources = getResources();

		// Builds the notification
		CharSequence startupText = resources
				.getString(R.string.notification_startup);
		Notification notification = new Notification(R.drawable.icon,
				startupText, 0);
		notification.flags |= Notification.FLAG_ONGOING_EVENT;
		notification.flags |= Notification.FLAG_NO_CLEAR;
		// NOTE 'notification.when = 0' disables the display of the time in the notification

		// Defines the notification's expanded message
		CharSequence contentTitle = resources.getString(R.string.app_name);
		CharSequence contentText = resources
				.getString(R.string.notification_text);

		// Defines the Intent that will be triggered when the notification is clicked
		Intent notificationIntent = new Intent(Intent.ACTION_VIEW, Uri
				.parse("http://www.google.com"));
		PendingIntent contentIntent = PendingIntent.getActivity(this, 0,
				notificationIntent, 0);

		Context context = getApplicationContext();
		notification.setLatestEventInfo(context, contentTitle, contentText,
				contentIntent);
		// After the notification's layout has been filled, we reset the time
		// that will be used to place it on the edge of the notification bar
		// in order to hide its icon
		notification.when = TIME_HIDDEN;

		// The following line only changes the icon displayed in the notification bar when shrinked
		// the icon displayed when it is expanded is the previous icon set, when the notification was instanciated.
		// Together with a placement to the right (or left depending on the SDK version), it makes the icon hidden.
		notification.icon = R.drawable.icon_hidden;

		return notification;
	}

	/** Creates a notification with a timestamp */
	private Notification buildNotificationLongdate() {

		Resources resources = getResources();

		// Builds the notification
		CharSequence startupText = resources
				.getString(R.string.notification_startup);
		Notification notification = new Notification(R.drawable.icon,
				startupText, 0);
		notification.flags |= Notification.FLAG_ONGOING_EVENT;
		notification.flags |= Notification.FLAG_NO_CLEAR;
		// We set the time before setLatestEventInfo has been called
		// => this should work, but TIME_HIDDEN will be displayed as an irrelevant timestamp
		notification.when = TIME_HIDDEN;

		// Defines the notification's expanded message
		CharSequence contentTitle = resources.getString(R.string.app_name);
		CharSequence contentText = resources
				.getString(R.string.notification_text);

		// Defines the Intent that will be triggered when the notification is clicked
		Intent notificationIntent = new Intent(Intent.ACTION_VIEW, Uri
				.parse("http://www.google.com"));
		;
		PendingIntent contentIntent = PendingIntent.getActivity(this, 0,
				notificationIntent, 0);

		Context context = getApplicationContext();
		notification.setLatestEventInfo(context, contentTitle, contentText,
				contentIntent);

		// The following line only changes the icon displayed in the notification bar when shrinked
		// the icon displayed when it is expanded is the previous icon set, when the notification was instanciated.
		// Together with a placement to the right (or left depending on the SDK version), it makes the icon hidden.
		notification.icon = R.drawable.icon_hidden;

		return notification;
	}

	private Notification buildNotificationVisibleicon() {

		Resources resources = getResources();

		// Builds the notification
		CharSequence startupText = resources
				.getString(R.string.notification_startup);
		Notification notification = new Notification(R.drawable.icon,
				startupText, 0);
		notification.flags |= Notification.FLAG_ONGOING_EVENT;
		notification.flags |= Notification.FLAG_NO_CLEAR;
		// NOTE 'notification.when = 0' disables the display of the time in the notification

		// Defines the notification's expanded message
		CharSequence contentTitle = resources.getString(R.string.app_name);
		CharSequence contentText = resources
				.getString(R.string.notification_text);

		// Defines the Intent that will be triggered when the notification is clicked
		Intent notificationIntent = new Intent(Intent.ACTION_VIEW, Uri
				.parse("http://www.google.com"));
		;
		PendingIntent contentIntent = PendingIntent.getActivity(this, 0,
				notificationIntent, 0);

		Context context = getApplicationContext();
		notification.setLatestEventInfo(context, contentTitle, contentText,
				contentIntent);

		// We don't set the time : the icon will be placed somewhere in the notification bar,
		// using some place between 2 other icons...
		// notification.when = TIME_HIDDEN;

		// The following line only changes the icon displayed in the notification bar when reduced
		// the icon displayed when it is expanded is the previous icon set, when the notification was instanciated.
		// Together with a placement to the right (or left depending on the SDK version), it makes the icon hidden.
		notification.icon = R.drawable.icon_hidden;

		return notification;
	}

	/**
	 * Depending on the action of the given Intent, will build a different
	 * notification.
	 * 
	 * @see #ACTION_FULL, ...
	 * @see #buildNotificationFull(), ...
	 */
	@Override
	public void onStart(Intent intent, int startId) {
		Log.d(TAG, "Starting service...");

		// builds the notification depending on the given Intent
		Notification notification = null;
		if (ACTION_LONGDATE.equalsIgnoreCase(intent.getAction())) {
			notification = buildNotificationLongdate();
		} else if (ACTION_VISIBLEICON.equalsIgnoreCase(intent.getAction())) {
			notification = buildNotificationVisibleicon();
		} else /* including ACTION_FULL */{
			notification = buildNotificationFull();
		}

		// Notifies !
		Log.d(TAG, "Notifying...");
		NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
		mNotificationManager.notify(NOTIF_START, notification);

		// job done : the notification is displayed
		stopSelf();
	}

	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}

}
